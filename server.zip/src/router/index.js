import { createRouter } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import PageNotFound from '../views/PageNotFound.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    component: () => import('../views/AboutView.vue')
  },
  { path: '/:pathMatch(.*)*', component: PageNotFound },
]
// export default router
export default function(history) 
{
  return createRouter({
    history,
    routes
  })
}
