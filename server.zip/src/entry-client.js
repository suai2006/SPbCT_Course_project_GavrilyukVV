import { createSSRApp } from 'vue';
import { createWebHistory } from 'vue-router'
import createRouter from './router'
import App from './App.vue';

// логика инициализации, специфичная для клиента...

const app = createSSRApp(App)
const router = createRouter(createWebHistory())
app.use(router)
// это предполагает, что в шаблоне App.vue будет корневой элемент с `id="app"`
router.isReady().then(() => {
    app.mount('#app')
})